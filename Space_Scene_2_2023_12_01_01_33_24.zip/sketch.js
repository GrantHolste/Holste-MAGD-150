function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(100);
  
  strokeWeight(1)
  stroke (1)
  fill (255, 100, 100)
  ellipse (100, 150, 50, 50)
  
  strokeWeight(1)
  stroke (1);
  fill (225, 45, 75);
  ellipse (250, 250, 200,200);
  
  noFill();
stroke(245);
  strokeWeight(5)
bezier(250, 250, 10, 1000, 1000, 0, 100, 0, 0, 0, 100, 0);
 
  strokeWeight(1)
  stroke(1)
  fill(234,233,200)
 triangle (260, 260, 240, 250, 255, 240 ) 
  
  noStroke()
  fill(225,150,20)
quad(245,250,255,255,255,270,235,260)
  
  fill(100,200,200)
  strokeWeight(1)
  stroke(1)
  ellipse(249,253,10,10)
  
}