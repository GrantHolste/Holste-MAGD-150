function setup() {
  createCanvas(500, 500);
  let fs = 60;
  frameRate(fs);
  angleMode(RADIANS);

  
}

function draw() {
  background(69);
  colorMode(RGB, 255);
let a = 69
let b = 100
let c = 22
let d = 50
    stroke(0,0,0)
    strokeWeight(1);
  noFill()
  ellipse(250,250,100,100);
  ellipse(250,250,pow(100,2),pow(100,2));
  ellipse(250,250,pow(100,3),pow(100,3));
  ellipse(250,250,pow(100,4),pow(100,4));
  ellipse(250,250,pow(100,5),pow(100,5));
  
  strokeWeight(10);
  stroke(200,0,0);
  fill(225,225,225);
  ellipse(b,b,a,a);
  ellipse(b,b,c,c);
  ellipse(b+b+b+b,b,a,a);
  ellipse(b+b+b+b,b,c,c);
  ellipse(b+b+d,b+b+d,b,b)
  ellipse(b+b+d,b+b+d,d,d)
  
  strokeWeight(1);
  stroke(255,100,100);
  line(mouseX, 0, mouseX, 500);
  line(0, mouseY, 500, mouseY);
  strokeWeight(5)
  stroke(255,105,180)
  line(mouseX, mouseY, pmouseX, pmouseY);
  print(pmouseX + ' -> ' + mouseX);
  
  
}