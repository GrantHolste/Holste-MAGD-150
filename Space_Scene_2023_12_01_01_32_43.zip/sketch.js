function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(177);
  fill(64);
  noStroke()
  ellipse(55, 70, 60, 60);
  fill (166);
  stroke(1);
  strokeWeight(1)
  ellipse(55, 73, 100, 14);
  strokeWeight (30);
  point(99, 45);
  noStroke();
  fill(64);
  ellipse(55, 69, 65, 10);
  stroke (220)
  strokeWeight (2)
  strokeCap (ROUND)
  line(82, 53, 120, 35);
}